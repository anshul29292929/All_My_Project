<?php
$db_hostname = "127.0.0.1";
$db_username = "root";
$db_password = "mansiji";
$db_name = "srmu_course";

$conn = mysqli_connect($db_hostname, $db_username, $db_password, $db_name);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Escape user inputs to prevent SQL injection
$userid = mysqli_real_escape_string($conn, $_POST["userid"]);
$student_name = mysqli_real_escape_string($conn, $_POST["name"]);
$table_name = mysqli_real_escape_string($conn, $_POST["table_name"]);

if($table_name===""){
    echo "select-course";
    exit();
}

// SQL query
$sql = "UPDATE $table_name SET student_name = '$student_name' WHERE roll_no = '$userid'";

// Execute query
$result = mysqli_query($conn, $sql);

// Check for errors
if (!$result) {
    mysqli_error($conn);
    echo "error";
}
else{
    echo "edited";
}

// Close connection
mysqli_close($conn);
?>
