<?php
$db_hostname = "127.0.0.1";
$db_username = "root";
$db_password = "mansiji";
$db_name = "srmu_course";

// Establish database connection
$conn = mysqli_connect($db_hostname, $db_username, $db_password, $db_name);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Escape user inputs to prevent SQL injection
$userid = mysqli_real_escape_string($conn, $_POST["userid"]);
$table_name = mysqli_real_escape_string($conn, $_POST["table_name"]);

if($table_name===""){
    echo "select-course";
    exit();
}

// SQL query
$sql = "delete from $table_name where roll_no='$userid'";

// Execute query
$result = mysqli_query($conn, $sql);

// Check for errors
if (mysqli_affected_rows($conn) === 0) {
        echo "notexist";
    } else {
        echo "Error: " . mysqli_error($conn);
    }

// Close connection
mysqli_close($conn);
?>
