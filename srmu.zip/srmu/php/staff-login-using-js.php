<?php
$db_hostname = "127.0.0.1";
$db_username = "root";
$db_password = "mansiji";
$db_name = "srmu";

$conn = mysqli_connect($db_hostname, $db_username, $db_password, $db_name);

if (!$conn) {
    error_log("Connection failed: " . mysqli_connect_error());
    echo "Error: Unable to connect to the database.";
    exit;
}

$name = mysqli_real_escape_string($conn, $_POST['name']);
$password = mysqli_real_escape_string($conn, $_POST['password']);

$sql = "SELECT * FROM staff_login WHERE staff_user_id = '$name' AND staff_pass = '$password'";
$result = mysqli_query($conn, $sql);

if (!$result) {
    error_log("Error: " . mysqli_error($conn));
    echo "Error: Unable to execute the query.";
    exit;
}

$row = mysqli_fetch_assoc($result);

if ($row) {
    echo 'success';
} else {
    echo 'invalid';
}

mysqli_close($conn);
?>
