<?php

$db_hostname="localhost";
$db_username="root";
$db_password="mansiji";
$db_name="srmu_course";

$conn = mysqli_connect($db_hostname, $db_username, $db_password, $db_name);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$table_name = $_POST['table_name'];


if($table_name===""){
    echo "select-course";
    exit();
}

$output='<div class="new-div">';


$sql="select * from $table_name";

$result=mysqli_query($conn,$sql);

while($row=mysqli_fetch_assoc($result)){
    $output.='<div class="asr-div-2">
              <label class="asr-label"> Roll number </label>
              <input value="' . $row["roll_no"] . '" type="number" id="asr-user-id" name="name-asr-user-id" class="asr-input" readonly>
              <label class="asr-label"> Name </label>
              <input value="' . $row["student_name"] . '" type="text" id="asr-name" name="name-asr-name" class="asr-input" readonly>
              <button type="button" id="asr-button-1" class="asr-button"> View Profile </button>';
                }

$output.='</div>';
mysqli_close($conn);

echo $output;

?>