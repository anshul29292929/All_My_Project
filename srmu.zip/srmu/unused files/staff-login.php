<?php
    $db_hostname = "127.0.0.1";
    $db_username = "root";
    $db_password = "mansiji";
    $db_name = "srmu";
    
    $conn = mysqli_connect($db_hostname, $db_username, $db_password, $db_name);
    if (!$conn) {
        echo "Connection failed: " . mysqli_connect_error();
        exit;
    }

    $name = $_POST['staff-user-id'];
    $password = $_POST['staff-password'];

    $sql = "SELECT * FROM staff_login WHERE staff_user_id = '$name' AND staff_pass = '$password'";

    $result = mysqli_query($conn, $sql);

    if (!$result) {
        echo "Error: " . mysqli_error($conn);
    }

    $row = mysqli_fetch_assoc($result);
    
    print_r($row); // or var_dump($row);

    if ($row) {
        $_SESSION['name'] = $username;
        header("Location: user.php");
        exit();
    } else {
        header("Location: login-error.html");
    }

    mysqli_close($conn);
?>
